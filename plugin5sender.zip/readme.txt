=== 5sender SMS Woocommerce ===
Contributors: Lynos HK 
Site:https://lynoshk229.com/
Tags: sms woocommerce, sms marketing, sms notification 
Requires at wordpress: 5.9.2
Tested woocommerce up to: 6.3.1
Requires PHP: 7.3.2
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==
Plugin de notification d'achat et de commande woocommerce.

== Installation ==
Pour la réussite de l'installation de ce plugin, veuillez vous assurer que woocommerce est bien intallé.


1-Choisir le plugin
2-L'installer
3-L'activer
4-Mettre les informations de configuration